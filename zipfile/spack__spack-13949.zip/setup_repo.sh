#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "a3799b2c7bc8224f7cc4453e5cd6fdbea2cc71f1"
cd ..
