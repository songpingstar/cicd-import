#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "a22d52a67dffa8dbf1632ce17129de32ca39c591"
cd ..
