#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "e69efded329ebbcf5ccf74ef137dc1a80bd4b4a6"
cd ..
