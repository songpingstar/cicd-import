#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "518d1439c7c210ddb6c1bd6267fed62bb0cb8ab7"
cd ..
