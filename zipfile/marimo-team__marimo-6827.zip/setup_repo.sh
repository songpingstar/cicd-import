#!/bin/bash
mkdir -p /testbed
git clone https://github.com/marimo-team/marimo.git /testbed/marimo
cd /testbed/marimo
git checkout "2f6365df8d12fde53e589ebba6559ff429159270"
cd ..
