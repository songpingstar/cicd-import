#!/bin/bash
mkdir -p /testbed
git clone https://github.com/marimo-team/marimo.git /testbed/marimo
cd /testbed/marimo
git checkout "2dfefad9256811d06c437c8091e34efb8d9a5ecf"
cd ..
