#!/bin/bash
mkdir -p /testbed
git clone https://github.com/marimo-team/marimo.git /testbed/marimo
cd /testbed/marimo
git checkout "6ed5c9f4e8f4c726eee58bc093daf642e4b2a2de"
cd ..
