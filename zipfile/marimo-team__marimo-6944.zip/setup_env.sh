#!/bin/bash
cd /testbed/marimo
##################pixi###########################
# pip install -q --upgrade pip setuptools
# pixi run make check-prereqs
# pixi run make fe
# pixi run make py
###############################################

##################uv###########################
# apt update
# apt install -y nodejs npm tree
# pip install -q --upgrade pip setuptools
# pip install -q uv
# uv add pytest pytest-asyncio pytest-timeout nbformat
# bash scripts/test-lsp.sh
# ls 
# uv pip install dist/marimo*whl
################################################

##################hatch###########################
pip install -q --upgrade pip setuptools
pip install hatch
hatch version
hatch run +py=3.12 test:python --version
mkdir -p marimo/_static/assets
cp frontend/index.html marimo/_static/index.html
cp frontend/public/favicon.ico marimo/_static/favicon.ico
###############################################

##################pip###########################
# git submodule sync
# git submodule update --init --recursive --checkout
# pip install -q --upgrade pip setuptools
# pip install -e .
# pip install -r requirements.txt
# pip install -q --upgrade pytest
###############################################
