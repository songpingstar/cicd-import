#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "7af8c206ace3e6fd99bef11501e1def601bbdd78"
cd ..
