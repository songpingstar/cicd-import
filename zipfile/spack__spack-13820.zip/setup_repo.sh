#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "9a6a19d464f31d301fb333c5110042f9ead5d501"
cd ..
