#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "04e999162d485ea7c43dce3043e0a6262e1d399e"
cd ..
