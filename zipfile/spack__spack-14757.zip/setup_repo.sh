#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "ba25bb3050d828fc408f2e28c324546604410857"
cd ..
