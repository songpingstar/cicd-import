#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "a97faeb3c7115f9eb17a63d14464296e8168c767"
cd ..
