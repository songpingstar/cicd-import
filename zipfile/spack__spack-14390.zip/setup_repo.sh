#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "8283d87f6a1a7ea2e92e9adfb7ac42ce94a6e4d5"
cd ..
