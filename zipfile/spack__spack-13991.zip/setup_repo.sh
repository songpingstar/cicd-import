#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "99c9365974c4a4e282b7e988bb1942c19129cb02"
cd ..
