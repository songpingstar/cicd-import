#!/bin/bash
mkdir -p /testbed
git clone https://github.com/marimo-team/marimo.git /testbed/marimo
cd /testbed/marimo
git checkout "6ba411b740a828a99990cb0b9f022e8cc95c1483"
cd ..
