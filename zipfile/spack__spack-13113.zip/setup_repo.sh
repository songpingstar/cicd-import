#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "469bef880a402ce8d7b4b3b804c18f32884c6fb4"
cd ..
