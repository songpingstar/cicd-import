#!/bin/bash
mkdir -p /testbed
git clone https://github.com/strawberry-graphql/strawberry.git /testbed/strawberry
cd /testbed/strawberry
git checkout "f9e5eda37bfbac91471be24032c072f6f992c338"
cd ..
