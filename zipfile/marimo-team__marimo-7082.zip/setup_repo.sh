#!/bin/bash
mkdir -p /testbed
git clone https://github.com/marimo-team/marimo.git /testbed/marimo
cd /testbed/marimo
git checkout "c8040df6666a2dd0c1f8ec7d0b8bf70aca1261e1"
cd ..
