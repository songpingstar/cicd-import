#!/bin/bash
mkdir -p /testbed
git clone https://github.com/marimo-team/marimo.git /testbed/marimo
cd /testbed/marimo
git checkout "e1006ded30c75c04b395b93cb70f5396d60ca25f"
cd ..
