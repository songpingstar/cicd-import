#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "52df2309cb7ab3a2da67e6d0461b04d017416223"
cd ..
