#!/bin/bash
mkdir -p /testbed
git clone https://github.com/marimo-team/marimo.git /testbed/marimo
cd /testbed/marimo
git checkout "b8ef760881b59752e07ef35dc5c0ed5aa1de46c6"
cd ..
