#!/bin/bash
mkdir -p /testbed
git clone https://github.com/marimo-team/marimo.git /testbed/marimo
cd /testbed/marimo
git checkout "c212b1db588080dd14d73f9d805063275b859c21"
cd ..
