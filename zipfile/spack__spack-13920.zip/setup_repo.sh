#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "19dba603ad0e98700c681e675972fbaa7c9aed6c"
cd ..
