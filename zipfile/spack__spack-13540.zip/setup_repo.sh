#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "a8228e1aec259af137e6ab59f5e6df4cf454d0f5"
cd ..
