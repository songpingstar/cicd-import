#!/bin/bash
mkdir -p /testbed
git clone https://github.com/marimo-team/marimo.git /testbed/marimo
cd /testbed/marimo
git checkout "957609481359c61bbd02163e4c98dcfd43588dbd"
cd ..
