#!/bin/bash
mkdir -p /testbed
git clone https://github.com/strawberry-graphql/strawberry.git /testbed/strawberry
cd /testbed/strawberry
git checkout "850de283d0b88f210999c2b1f54f2fd056b3801e"
cd ..
