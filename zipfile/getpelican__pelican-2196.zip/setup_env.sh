#!/bin/bash
cd /testbed/pelican
apt-get update -qq
pip install -q --upgrade pip setuptools
pip install -q tox==2.5.0
pip install -e .
#pip install -q -r requirements.txt
#pip install -q -r test-requirements.txt
#pip install -q --upgrade pytest
pip install -v pytest==6.2.5
