#!/bin/bash
mkdir -p /testbed
git clone https://github.com/getpelican/pelican.git /testbed/pelican
cd /testbed/pelican
git checkout "56a483475b0a42bd13cf114248c9141c9051ed84"
cd ..
