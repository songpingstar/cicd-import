#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "80ea96312ffe50f2b62ed823baa19a2f904f8e91"
cd ..
