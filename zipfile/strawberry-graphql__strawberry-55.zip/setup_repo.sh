#!/bin/bash
mkdir -p /testbed
git clone https://github.com/strawberry-graphql/strawberry.git /testbed/strawberry
cd /testbed/strawberry
git checkout "6da4d23f42c3091a0707c62b66f38c0501e294c6"
cd ..
