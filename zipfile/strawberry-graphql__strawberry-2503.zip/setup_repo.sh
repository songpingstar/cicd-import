#!/bin/bash
mkdir -p /testbed
git clone https://github.com/strawberry-graphql/strawberry.git /testbed/strawberry
cd /testbed/strawberry
git checkout "cf4e491b5c49877f55664c951f18970fc2c4699e"
cd ..
