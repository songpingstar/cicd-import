#!/bin/bash
mkdir -p /testbed
git clone https://github.com/marimo-team/marimo.git /testbed/marimo
cd /testbed/marimo
git checkout "0238fb935dd190af91619d58c9fe56572175b816"
cd ..
