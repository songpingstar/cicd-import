#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "af3c238c3162c1c2bf0ec95e0ba362873d5b5c87"
cd ..
