#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "845df79ac6ff886fdfae7dc72c3d29fb6a496521"
cd ..
