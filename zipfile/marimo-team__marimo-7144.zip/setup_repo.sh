#!/bin/bash
mkdir -p /testbed
git clone https://github.com/marimo-team/marimo.git /testbed/marimo
cd /testbed/marimo
git checkout "1fe8e40def4ec6471faf19280378f861fe29e9c6"
cd ..
