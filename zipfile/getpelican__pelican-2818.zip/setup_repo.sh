#!/bin/bash
mkdir -p /testbed
git clone https://github.com/getpelican/pelican.git /testbed/pelican
cd /testbed/pelican
git checkout "e4d9c41a77b45cb7ff6b8d1732623990adf65931"
cd ..
