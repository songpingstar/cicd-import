#!/bin/bash
mkdir -p /testbed
git clone https://github.com/strawberry-graphql/strawberry.git /testbed/strawberry
cd /testbed/strawberry
git checkout "c0decf9a5819b503fc1de62f0ad9066f9189bae9"
cd ..
