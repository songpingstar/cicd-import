#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "9538889f1c4de2674f4849b6da6d4b68d4ea9b4e"
cd ..
