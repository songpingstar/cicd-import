#!/bin/bash
mkdir -p /testbed
git clone https://github.com/marimo-team/marimo.git /testbed/marimo
cd /testbed/marimo
git checkout "681edb79feba557307327f6e92f080ca826b6841"
cd ..
