#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "36558dc26221a796c0f0aa7e8352fa22d1563480"
cd ..
