#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "bec283080292f90f8f97dcb7ceb070a9a86ed388"
cd ..
