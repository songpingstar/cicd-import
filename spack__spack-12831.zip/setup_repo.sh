#!/bin/bash
mkdir -p /testbed
git clone https://github.com/spack/spack.git /testbed/spack
cd /testbed/spack
git checkout "6df57bb2d0619a22b0bb0a5028b7caef7f31e722"
cd ..
