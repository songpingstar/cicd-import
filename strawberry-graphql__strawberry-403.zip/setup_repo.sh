#!/bin/bash
mkdir -p /testbed
git clone https://github.com/strawberry-graphql/strawberry.git /testbed/strawberry
cd /testbed/strawberry
git checkout "bc0f673f9b25123e20088d4015d5a7f11579c373"
cd ..
